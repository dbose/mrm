# CCR Model Validation Example - CPS 230 Compliance

**Production-Grade Counterparty Credit Risk Model with Regulatory Documentation**

This example demonstrates operational Model Risk Management (MRM) using the MRM Core framework with full APRA CPS 230 compliance.

## What's Included

### 1. **Advanced CCR Model** (`src/models/ccr/ccr_model.py`)

Vanilla Monte Carlo implementation for:
- **Expected Exposure (EE)** - Mean exposure across simulation paths
- **Potential Future Exposure (PFE)** - 95th percentile exposure
- **Credit Valuation Adjustment (CVA)** - Mark-to-market adjustment for counterparty risk
- **Exposure at Default (EAD)** - Basel III capital calculation
- **Regulatory Capital** - CVA and CCR capital charges

**Features:**
- 10,000 path Monte Carlo simulation
- Hull-White interest rate model
- Geometric Brownian motion for FX
- Mean-reverting credit spreads
- Support for IRS and FX Forward products

### 2. **Validation Trigger System** (`src/models/ccr/validation_triggers.py`)

Automated detection of when re-validation is required based on:

**CPS 230 Para 34 (Annual Testing):**
- Annual validation due date
- Quarterly monitoring requirements

**CPS 230 Para 40 (Fitness for Purpose):**
- Performance degradation (RMSE, MAE)
- Backtesting failures
- Data quality issues (PSI, missing data)
- Market regime shifts
- Correlation breakdowns

**Trigger Categories:**
- Time-based (regulatory deadlines)
- Performance-based (model accuracy)
- Data quality (input data fitness)
- Market regime (environment changes)
- Governance (audit findings, issues)

### 3. **CPS 230 Validation Tests** (`tests/ccr/test_cps230_compliance.py`)

Six specialized tests aligned with CPS 230 requirements:

| Test | CPS 230 Reference | Purpose |
|------|-------------------|---------|
| `ModelCoverage` | Para 40 | Ensures model covers intended products |
| `Backtesting` | Para 40 | Statistical validation (Kupiec test) |
| `StressTesting` | Para 34 | Validates performance under stress |
| `DataQuality` | Para 40 | Ensures input data fitness |
| `Documentation` | Para 40 | Verifies adequate documentation |
| `PerformanceMonitoring` | Para 40 | Ongoing effectiveness tracking |

### 4. **Regulatory Documentation Generator** (`src/models/ccr/cps230_documentation.py`)

Automated generation of:
- **Validation Report** - Comprehensive CPS 230 compliance report
- **Model Inventory** - Regulatory model catalog
- **Audit Trail** - Change and execution logs
- **Evidence Package** - Complete audit-ready documentation

**Each document maps validation activities to specific CPS 230 paragraphs**

### 5. **Complete Configuration** (`models/ccr/ccr_monte_carlo.yml`)

Production-ready model configuration with:
- CPS 230 classification
- Validation trigger thresholds
- Test suite definitions
- Governance workflows
- Documentation requirements
- Evidence mapping

## CPS 230 Compliance

### APRA Prudential Standard CPS 230 - Operational Risk Management

**Effective:** 1 July 2025

This example demonstrates full compliance with:

#### Paragraph 34 - Business Continuity Testing
> "Test and review effectiveness at least annually and after material changes"

**Implementation:**
- Annual validation requirement (365-day trigger)
- Stress testing under extreme scenarios
- Post-implementation reviews
- Material change detection

#### Paragraph 40 - Information Asset Fitness
> "Information assets supporting critical operations must remain fit for purpose"

**Implementation:**
- Ongoing performance monitoring
- Data quality assessments
- Backtesting and validation
- Model coverage analysis
- Comprehensive documentation

#### Paragraph 41 - Information Security
> "Maintain information security over information assets"

**Implementation:**
- Audit trail for all model activities
- Access control documentation
- Change management logs

## Quick Start

### Run the Complete Example

```bash
# Navigate to example directory
cd ccr_example

# Run the validation example
python run_ccr_validation.py
```

This will:
1. ✅ Initialize CCR Monte Carlo model
2. ✅ Calculate exposures (EE, PFE, CVA, EAD, Capital)
3. ✅ Generate sample portfolio
4. ✅ Assess validation triggers
5. ✅ Run CPS 230 compliance tests
6. ✅ Generate regulatory documentation
7. ✅ Produce evidence package

### Expected Output

```
================================================================================
CCR MODEL VALIDATION - CPS 230 COMPLIANCE DEMONSTRATION
================================================================================

STEP 1: Initializing CCR Model...
✓ CCR Model initialized successfully

STEP 2: Running CCR Calculations (Monte Carlo Simulation)...
✓ Expected Exposure (avg): $45,234.12
✓ PFE (95%): $89,567.45
✓ EEPE: $48,901.23
✓ CVA: $1,234.56
✓ EAD: $68,462.72
✓ Total Capital: $12,345.67

...

================================================================================
CPS 230 COMPLIANCE STATEMENT
================================================================================

The CCR Monte Carlo Model has been validated in accordance with
APRA Prudential Standard CPS 230 - Operational Risk Management.

All validation tests have been executed successfully:
  ✓ Model Coverage (CPS 230 Para 40)
  ✓ Backtesting (CPS 230 Para 40)
  ✓ Stress Testing (CPS 230 Para 34)
  ✓ Data Quality (CPS 230 Para 40)
  ✓ Documentation (CPS 230 Para 40)
  ✓ Performance Monitoring (CPS 230 Para 40)

The model is APPROVED for production use.
```

### Generated Documentation

All documentation is saved to `docs/regulatory/`:

```
docs/regulatory/
├── CPS230_Validation_Report_20260206_123456.md
├── Model_Inventory_CCR.json
├── Audit_Trail.csv
└── Evidence_Package_Index.md
```

## Project Structure

```
ccr_example/
├── src/
│   └── models/
│       └── ccr/
│           ├── ccr_model.py                    # CCR Monte Carlo implementation
│           ├── validation_triggers.py          # Trigger detection system
│           └── cps230_documentation.py         # Documentation generator
│
├── tests/
│   └── ccr/
│       └── test_cps230_compliance.py           # CPS 230 validation tests
│
├── models/
│   └── ccr/
│       └── ccr_monte_carlo.yml                 # Model configuration
│
├── data/
│   ├── portfolio.csv                           # Generated portfolio
│   ├── validation_data.csv                     # Historical data
│   └── stress_scenarios.csv                    # Stress test scenarios
│
├── docs/
│   ├── regulatory/                             # Generated documentation
│   └── templates/                              # Report templates
│
├── run_ccr_validation.py                       # Main example script
├── mrm_project.yml                             # Project configuration
├── profiles.yml                                # Environment configuration
└── README.md                                   # This file
```

## Model Details

### CCR Model Specifications

**Model Type:** Counterparty Credit Risk (Monte Carlo)

**Methodology:**
- Vanilla Monte Carlo simulation (10,000 paths)
- Hull-White model for interest rates
- Geometric Brownian motion for FX rates
- Mean-reverting credit spreads

**Regulatory Framework:**
- APRA CPS 230 - Operational Risk Management
- Basel III - Counterparty Credit Risk Capital Framework
- BCBS 279 - SA-CCR (Standardized Approach for CCR)
- FRTB - Fundamental Review of the Trading Book

**Products Supported:**
- Interest Rate Swaps (IRS)
- FX Forward Contracts

**Outputs:**
- Expected Exposure (EE)
- Potential Future Exposure (PFE) at 95% confidence
- Effective Expected Positive Exposure (EEPE)
- Credit Valuation Adjustment (CVA)
- Exposure at Default (EAD) with alpha multiplier (1.4)
- Regulatory Capital (CVA + CCR components)

### Model Parameters

```yaml
monte_carlo:
  n_paths: 10000          # Number of simulation paths
  n_steps: 100            # Time steps per path
  seed: 42                # Random seed for reproducibility
  confidence_level: 0.95  # PFE confidence level

market_model:
  initial_rate: 0.04      # 4% initial interest rate
  rate_volatility: 0.01   # 1% rate vol
  fx_volatility: 0.10     # 10% FX vol
  spread_volatility: 0.30 # 30% spread vol
  mean_reversion: 0.15    # Rate mean reversion speed
  correlation: 0.30       # Cross-factor correlation
```

## Validation Triggers

### Trigger Thresholds (Configurable)

| Category | Trigger | Threshold | CPS 230 Ref |
|----------|---------|-----------|-------------|
| **Time** | Annual Validation | 365 days | Para 34 |
| **Time** | Quarterly Monitoring | 90 days | Para 40 |
| **Performance** | Backtest P-value | < 0.01 | Para 40 |
| **Performance** | Breach Rate | > 5% | Para 40 |
| **Performance** | RMSE Increase | > 20% | Para 40 |
| **Data** | Missing Data | > 5% | Para 40 |
| **Data** | PSI (Population Drift) | > 0.25 | Para 40 |
| **Data** | Data Quality Score | < 0.80 | Para 40 |
| **Market** | VIX Increase | > 50% | Para 40 |
| **Market** | Correlation Shift | > 0.30 | Para 40 |

### Trigger Actions

- **REGULATORY**: Immediate full re-validation required (30 days)
- **CRITICAL**: Urgent model review and re-validation (60 days)
- **WARNING**: Enhanced monitoring and investigation
- **INFO**: Continue monitoring

## CPS 230 Validation Tests

### Test 1: Model Coverage
**CPS 230 Reference:** Para 40 - Model must be fit for purpose

Validates that the model covers all trade types in the portfolio.

**Acceptance Criteria:** ≥95% coverage

### Test 2: Backtesting
**CPS 230 Reference:** Para 40 - Ongoing testing for effectiveness

Performs statistical backtesting using:
- Kupiec test (binomial test for VaR breaches)
- Christoffersen test (independence of breaches)

**Acceptance Criteria:**
- P-value ≥ 0.01
- Breach rate ≤ 5%

### Test 3: Stress Testing
**CPS 230 Reference:** Para 34 - Test under stress conditions

Tests model under extreme scenarios:
- 2008 Financial Crisis
- COVID Market Shock
- Sovereign Default

**Acceptance Criteria:** Model completes without error

### Test 4: Data Quality
**CPS 230 Reference:** Para 40 - Information asset quality

Checks:
- Missing data rate
- Data completeness
- Duplicate detection
- Critical column validation

**Acceptance Criteria:**
- Missing data < 5%
- Completeness ≥ 95%

### Test 5: Documentation
**CPS 230 Reference:** Para 40 - Documentation requirements

Validates presence of:
- Model description
- Methodology documentation
- Assumptions register
- Limitations analysis
- Validation reports

**Acceptance Criteria:** ≥80% documentation coverage

### Test 6: Performance Monitoring
**CPS 230 Reference:** Para 40 - Ongoing performance monitoring

Tracks:
- RMSE vs baseline
- Prediction correlation
- Performance degradation

**Acceptance Criteria:**
- RMSE increase < 20%
- Correlation ≥ 0.70

## Using with MRM Framework

### Option 1: Standalone Execution

```bash
python run_ccr_validation.py
```

### Option 2: MRM Framework Integration

```bash
# Initialize MRM project
mrm init ccr_validation

# Run validation tests
mrm test --models ccr_monte_carlo

# Generate documentation
mrm docs generate --model ccr_monte_carlo

# View triggers
mrm triggers check --model ccr_monte_carlo
```

## Extending the Example

### Add New Trade Types

Edit `src/models/ccr/ccr_model.py`:

```python
def price_cds(self, notional, spread, maturity, ...):
    """Price Credit Default Swap"""
    # Implementation
```

### Add Custom Validation Tests

Create new test in `tests/ccr/`:

```python
from mrm.tests.base import MRMTest, TestResult
from mrm.tests.library import register_test

@register_test
class CPS230_CustomTest(MRMTest):
    name = "cps230.CustomTest"
    
    def run(self, model, dataset, **config):
        # Your test logic
        return TestResult(passed=True, score=0.95)
```

### Customize Trigger Thresholds

Edit `mrm_project.yml`:

```yaml
validation_triggers:
  performance:
    rmse_increase_threshold: 0.15  # 15% instead of 20%
```

## Regulatory References

### APRA CPS 230

**APRA Prudential Standard CPS 230** - Operational Risk Management  
**Effective Date:** 1 July 2025

Key paragraphs implemented:
- **Para 34:** Business continuity testing requirements
- **Para 40:** Information asset fitness for purpose
- **Para 41:** Information security requirements

Full standard: https://www.apra.gov.au/cps-230

### Basel III - CCR Framework

- **BCBS 279:** Standardized Approach for measuring Counterparty Credit Risk (SA-CCR)
- **Basel III:** CVA Capital Charge framework
- **EAD Calculation:** Alpha multiplier approach (1.4)

## Requirements

### Python Dependencies

```
numpy>=1.21.0
pandas>=1.3.0
scipy>=1.7.0
```

### MRM Framework

```bash
cd ../mrm-core
pip install -e .
```

## Support

For questions or issues:
1. Review the generated documentation in `docs/regulatory/`
2. Check the example output logs
3. Refer to CPS 230 compliance mapping
4. Review model configuration in `models/ccr/ccr_monte_carlo.yml`

## License

Apache 2.0 - See LICENSE

## Authors

**Model Risk Management Team**  
Example Bank Limited

---

**CPS 230 Compliance Notice:** This example is for demonstration purposes. Actual production deployment requires full regulatory approval and institutional governance processes.
