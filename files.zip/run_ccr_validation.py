"""
Complete CCR Model Validation Example with CPS 230 Compliance

This script demonstrates:
1. CCR model implementation (Monte Carlo)
2. Validation trigger assessment
3. CPS 230 compliant testing
4. Professional regulatory documentation
5. Evidence package generation

Run this to see the full MRM workflow for operational risk management
"""

import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "mrm-core"))

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import logging

# Import CCR model components
from src.models.ccr.ccr_model import (
    CCRModel, MarketModel, Counterparty, Trade
)
from src.models.ccr.validation_triggers import (
    ValidationTriggerSystem, TriggerResult
)
from src.models.ccr.cps230_documentation import (
    CPS230DocumentationGenerator
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def generate_sample_portfolio() -> pd.DataFrame:
    """Generate sample counterparty portfolio"""
    np.random.seed(42)
    
    n_trades = 50
    
    portfolio = pd.DataFrame({
        'trade_id': [f"TRADE_{i:03d}" for i in range(n_trades)],
        'counterparty': np.random.choice(
            ['MegaBank Corp', 'Global Finance Inc', 'Capital Partners LLC'],
            n_trades
        ),
        'trade_type': np.random.choice(
            ['IRS', 'FX_Forward'],
            n_trades,
            p=[0.6, 0.4]
        ),
        'notional': np.random.uniform(1_000_000, 50_000_000, n_trades),
        'maturity_years': np.random.uniform(1, 10, n_trades),
        'strike': np.random.uniform(0.03, 0.05, n_trades),
        'currency': 'AUD'
    })
    
    return portfolio


def generate_validation_data(n_samples: int = 200) -> pd.DataFrame:
    """Generate synthetic validation data for backtesting"""
    np.random.seed(42)
    
    # Generate synthetic actuals with some noise
    predicted = np.random.uniform(100_000, 500_000, n_samples)
    
    # Actuals = predicted + noise (correlated)
    noise = np.random.normal(0, 50_000, n_samples)
    actual = predicted + noise
    
    # Add some systematic bias for recent data (simulates model degradation)
    recent_idx = int(n_samples * 0.7)
    actual[recent_idx:] += 20_000  # Slight underestimation in recent period
    
    validation_data = pd.DataFrame({
        'date': pd.date_range(end=datetime.now(), periods=n_samples, freq='D'),
        'predicted': predicted,
        'actual': actual
    })
    
    return validation_data


def run_ccr_validation_example():
    """
    Complete CCR validation example with CPS 230 compliance
    """
    
    print("\n" + "="*80)
    print("CCR MODEL VALIDATION - CPS 230 COMPLIANCE DEMONSTRATION")
    print("="*80)
    print(f"Date: {datetime.now().strftime('%d %B %Y %H:%M:%S')}")
    print(f"Institution: Example Bank Limited (ABN 12 345 678 901)")
    print(f"Model: CCR Monte Carlo Model v1.0.0")
    print(f"Regulatory Framework: APRA CPS 230")
    print("="*80 + "\n")
    
    # ==========================================
    # STEP 1: Initialize CCR Model
    # ==========================================
    print("STEP 1: Initializing CCR Model...")
    print("-" * 80)
    
    # Define counterparty
    counterparty = Counterparty(
        name="MegaBank Corp",
        rating="A",
        pd_1y=0.0015,  # 15 bps
        lgd=0.40
    )
    
    print(f"Counterparty: {counterparty.name}")
    print(f"Rating: {counterparty.rating}")
    print(f"PD (1Y): {counterparty.pd_1y:.4%}")
    print(f"LGD: {counterparty.lgd:.2%}")
    
    # Define representative trade
    trade = Trade(
        trade_id="IRS_001",
        counterparty=counterparty.name,
        trade_type="IRS",
        notional=10_000_000,
        maturity_years=5.0,
        strike=0.04
    )
    
    print(f"\nRepresentative Trade: {trade.trade_id}")
    print(f"Type: {trade.trade_type}")
    print(f"Notional: ${trade.notional:,.0f}")
    print(f"Maturity: {trade.maturity_years} years")
    
    # Initialize models
    market_model = MarketModel(seed=42)
    ccr_model = CCRModel(counterparty, market_model, seed=42)
    
    print("\n✓ CCR Model initialized successfully")
    
    # ==========================================
    # STEP 2: Run CCR Calculations
    # ==========================================
    print("\n" + "="*80)
    print("STEP 2: Running CCR Calculations (Monte Carlo Simulation)...")
    print("-" * 80)
    
    # Calculate exposure profile
    print("Running Monte Carlo simulation (10,000 paths)...")
    exposure = ccr_model.calculate_exposure_profile(trade, n_paths=10000)
    
    print(f"✓ Expected Exposure (avg): ${np.mean(exposure['ee']):,.2f}")
    print(f"✓ PFE (95%): ${np.max(exposure['pfe']):,.2f}")
    print(f"✓ EEPE: ${exposure['eepe']:,.2f}")
    
    # Calculate CVA
    print("\nCalculating Credit Valuation Adjustment...")
    cva_results = ccr_model.calculate_cva(exposure)
    print(f"✓ CVA: ${cva_results['cva']:,.2f}")
    
    # Calculate EAD
    print("\nCalculating Exposure at Default...")
    ead = ccr_model.calculate_ead(exposure)
    print(f"✓ EAD: ${ead:,.2f}")
    
    # Calculate capital
    print("\nCalculating Regulatory Capital Charge...")
    capital = ccr_model.calculate_capital_charge(exposure, cva_results, ead)
    print(f"✓ CVA Capital: ${capital['cva_capital']:,.2f}")
    print(f"✓ CCR Capital: ${capital['ccr_capital']:,.2f}")
    print(f"✓ Total Capital: ${capital['total_capital']:,.2f}")
    
    # ==========================================
    # STEP 3: Generate Portfolio Data
    # ==========================================
    print("\n" + "="*80)
    print("STEP 3: Generating Sample Portfolio...")
    print("-" * 80)
    
    portfolio = generate_sample_portfolio()
    print(f"✓ Generated portfolio with {len(portfolio)} trades")
    print(f"  - IRS trades: {sum(portfolio['trade_type'] == 'IRS')}")
    print(f"  - FX Forward trades: {sum(portfolio['trade_type'] == 'FX_Forward')}")
    print(f"  - Total notional: ${portfolio['notional'].sum():,.0f}")
    
    # Save portfolio
    portfolio_path = Path("data/portfolio.csv")
    portfolio_path.parent.mkdir(parents=True, exist_ok=True)
    portfolio.to_csv(portfolio_path, index=False)
    print(f"✓ Portfolio saved to: {portfolio_path}")
    
    # ==========================================
    # STEP 4: Validation Trigger Assessment
    # ==========================================
    print("\n" + "="*80)
    print("STEP 4: Validation Trigger Assessment (CPS 230 Para 34 & 40)...")
    print("-" * 80)
    
    # Initialize trigger system
    trigger_system = ValidationTriggerSystem(
        model_name="CCR Monte Carlo Model",
        last_validation_date=datetime(2024, 2, 1)  # 1 year ago
    )
    
    # Prepare metrics for trigger checks
    validation_data = generate_validation_data(200)
    
    performance_metrics = {
        'backtest_pvalue': 0.25,  # Good
        'rmse_baseline': 100_000,
        'rmse_current': 118_000,  # 18% increase
        'breach_rate': 0.03  # 3% - acceptable
    }
    
    data_metrics = {
        'missing_rate': 0.02,  # 2% - good
        'psi': 0.18,  # Moderate shift
        'dq_score': 0.92  # Good quality
    }
    
    market_metrics = {
        'vix_change': 0.35,  # 35% increase
        'correlation_shift': 0.15  # Moderate
    }
    
    # Check all triggers
    print("Checking validation triggers...")
    triggers = trigger_system.check_all_triggers(
        performance_metrics=performance_metrics,
        data_metrics=data_metrics,
        market_metrics=market_metrics
    )
    
    triggered = [t for t in triggers if t.triggered]
    print(f"✓ Trigger assessment complete: {len(triggered)}/{len(triggers)} triggered")
    
    # Get recommendation
    recommendation = trigger_system.get_validation_recommendation(triggers)
    print(f"\nValidation Recommendation: {recommendation['recommendation']}")
    print(f"Priority: {recommendation['priority']}")
    print(f"Timeline: {recommendation['timeline']}")
    
    # Generate trigger report
    trigger_report = trigger_system.generate_trigger_report(triggers)
    print("\nTrigger Summary:")
    print(trigger_report[['Trigger', 'Status', 'Severity', 'Action Required']].to_string(index=False))
    
    # ==========================================
    # STEP 5: Run CPS 230 Validation Tests
    # ==========================================
    print("\n" + "="*80)
    print("STEP 5: Running CPS 230 Validation Tests...")
    print("-" * 80)
    
    # Simulate test results (in practice, these would come from MRM framework)
    test_results = [
        {
            'test_name': 'CPS230.ModelCoverage',
            'passed': True,
            'score': 0.95,
            'details': {
                'coverage': 0.95,
                'cps230_ref': 'Para 40 - Model must be fit for purpose and cover intended use cases'
            }
        },
        {
            'test_name': 'CPS230.Backtesting',
            'passed': True,
            'score': 0.88,
            'details': {
                'kupiec_pvalue': 0.25,
                'breach_rate': 0.03,
                'cps230_ref': 'Para 40 - Ongoing testing to ensure model remains fit for purpose'
            }
        },
        {
            'test_name': 'CPS230.StressTesting',
            'passed': True,
            'score': 1.00,
            'details': {
                'scenarios_tested': 3,
                'cps230_ref': 'Para 34 - Test effectiveness under stress conditions'
            }
        },
        {
            'test_name': 'CPS230.DataQuality',
            'passed': True,
            'score': 0.92,
            'details': {
                'completeness': 0.98,
                'quality_score': 0.92,
                'cps230_ref': 'Para 40 - Information assets must be of sufficient quality'
            }
        },
        {
            'test_name': 'CPS230.Documentation',
            'passed': True,
            'score': 0.85,
            'details': {
                'documentation_coverage': 0.85,
                'cps230_ref': 'Para 40 - Documentation of critical systems'
            }
        },
        {
            'test_name': 'CPS230.PerformanceMonitoring',
            'passed': True,
            'score': 0.87,
            'details': {
                'rmse_increase': 0.18,
                'correlation': 0.92,
                'cps230_ref': 'Para 40 - Ongoing performance monitoring'
            }
        }
    ]
    
    passed_tests = sum(1 for t in test_results if t['passed'])
    print(f"✓ Tests completed: {passed_tests}/{len(test_results)} passed")
    
    for test in test_results:
        status = "✅ PASSED" if test['passed'] else "❌ FAILED"
        print(f"  {status} - {test['test_name']} (score: {test['score']:.2f})")
    
    # ==========================================
    # STEP 6: Generate CPS 230 Documentation
    # ==========================================
    print("\n" + "="*80)
    print("STEP 6: Generating CPS 230 Regulatory Documentation...")
    print("-" * 80)
    
    # Initialize documentation generator
    doc_generator = CPS230DocumentationGenerator(
        model_name="CCR Monte Carlo Model",
        model_version="1.0.0",
        institution_name="Example Bank Limited (ABN 12 345 678 901)",
        output_dir=Path("docs/regulatory")
    )
    
    # Prepare model details
    model_details = {
        'model_id': 'CCR_001',
        'owner': 'Market Risk Management',
        'developer': 'Quantitative Analytics Team',
        'validator': 'Model Risk Management',
        'approval_date': datetime(2024, 1, 15).isoformat(),
        'production_date': datetime(2024, 2, 1).isoformat()
    }
    
    # Model metrics
    model_metrics = {
        'eepe': exposure['eepe'],
        'pfe_95': np.max(exposure['pfe']),
        'cva': cva_results['cva'],
        'ead': ead,
        'total_capital': capital['total_capital']
    }
    
    # Validation events
    validation_events = [{
        'timestamp': datetime.now().isoformat(),
        'event_type': 'Full Model Validation',
        'user': 'MRM Team',
        'action': 'Comprehensive validation completed',
        'status': 'Success',
        'details': f"All {len(test_results)} tests passed"
    }]
    
    # Convert trigger results to dicts
    trigger_dicts = [t.to_dict() for t in triggers]
    
    # Generate evidence package
    print("Generating evidence package...")
    evidence = doc_generator.generate_evidence_package(
        test_results=test_results,
        trigger_results=trigger_dicts,
        model_metrics=model_metrics,
        model_details=model_details,
        validation_events=validation_events
    )
    
    print("\n✓ CPS 230 Evidence Package Generated:")
    for doc_type, doc_path in evidence.items():
        print(f"  - {doc_type.replace('_', ' ').title()}: {doc_path}")
    
    # ==========================================
    # STEP 7: Summary Report
    # ==========================================
    print("\n" + "="*80)
    print("STEP 7: Validation Summary")
    print("="*80)
    
    # Generate comprehensive summary
    summary = ccr_model.generate_report(trade, exposure, cva_results, ead, capital)
    
    print("\nCCR MODEL SUMMARY:")
    print("-" * 80)
    print(summary.to_string(index=False))
    
    # Final compliance statement
    print("\n" + "="*80)
    print("CPS 230 COMPLIANCE STATEMENT")
    print("="*80)
    print()
    print("The CCR Monte Carlo Model has been validated in accordance with")
    print("APRA Prudential Standard CPS 230 - Operational Risk Management.")
    print()
    print("All validation tests have been executed successfully:")
    print(f"  ✓ Model Coverage (CPS 230 Para 40)")
    print(f"  ✓ Backtesting (CPS 230 Para 40)")
    print(f"  ✓ Stress Testing (CPS 230 Para 34)")
    print(f"  ✓ Data Quality (CPS 230 Para 40)")
    print(f"  ✓ Documentation (CPS 230 Para 40)")
    print(f"  ✓ Performance Monitoring (CPS 230 Para 40)")
    print()
    print("Validation triggers have been assessed:")
    print(f"  - {len(triggered)} triggers active (out of {len(triggers)} total)")
    print(f"  - Recommendation: {recommendation['recommendation']}")
    print(f"  - Next validation due: {(datetime.now() + timedelta(days=365)).strftime('%d %B %Y')}")
    print()
    print("Evidence package includes:")
    print(f"  - Comprehensive validation report")
    print(f"  - Model inventory")
    print(f"  - Audit trail")
    print(f"  - CPS 230 compliance mapping")
    print()
    print("The model is APPROVED for production use in:")
    print(f"  - CVA calculation")
    print(f"  - Regulatory capital (SA-CCR)")
    print(f"  - Economic capital allocation")
    print(f"  - Counterparty limit monitoring")
    print()
    print("="*80)
    print("VALIDATION COMPLETE")
    print("="*80)
    print()
    print(f"All documentation saved to: {Path('docs/regulatory').absolute()}")
    print()
    
    return {
        'ccr_model': ccr_model,
        'trade': trade,
        'exposure': exposure,
        'cva': cva_results,
        'ead': ead,
        'capital': capital,
        'portfolio': portfolio,
        'test_results': test_results,
        'triggers': triggers,
        'recommendation': recommendation,
        'evidence_package': evidence
    }


if __name__ == "__main__":
    try:
        results = run_ccr_validation_example()
        print("\n✅ SUCCESS: CCR validation example completed successfully!")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
